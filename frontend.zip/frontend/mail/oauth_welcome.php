<?php echo Yii::t('frontend', 'Username') ?>: <?php echo $user->username ?><br>
<?php echo Yii::t('frontend', 'Password') ?>: <?php echo $password ?>
